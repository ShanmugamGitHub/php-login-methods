-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Nov 14, 2025 at 08:09 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login_methods`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('admin','user') DEFAULT 'user',
  `created_at` datetime DEFAULT current_timestamp(),
  `google_id` varchar(64) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `magic_token` varchar(64) DEFAULT NULL,
  `magic_expiry` datetime DEFAULT NULL,
  `magic_used` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `created_at`, `google_id`, `last_login`, `picture`, `magic_token`, `magic_expiry`, `magic_used`) VALUES
(3, 'kumar', 'kumar@gmail.com', '$2y$10$aL.y7TFYpChezh6tiM.DbOSk4bdMRvgfw9eQVMYGW1RptIN353zDe', 'admin', '2025-11-05 02:04:28', NULL, NULL, NULL, NULL, NULL, 0),
(5, 'admin', 'admin@gmail.com', '$2y$10$mYwU.y8SkxTrUs0IcS9r1eamuCcnxDKF11/O/lZ1fRbyfibbt8xau', 'admin', '2025-11-09 12:39:07', NULL, NULL, NULL, NULL, NULL, 0),
(6, 'user', 'user@gmail.com', '$2y$10$1B7ci3WfYLBSC2LscL1Qhu6gPjEE1lbYYlterBHKsAt5XcCaeCqRe', 'user', '2025-11-09 12:39:22', NULL, NULL, NULL, NULL, NULL, 0),
(9, 'Shammu', 'shammu.web@gmail.com', '$2y$10$LNUIa0yAwmx7fE5AnxcqJuODkvi9iJ9nZmzoiQAOpMjtwRDiye4vm', 'user', '2025-11-09 22:08:04', '104360142185394189799', '2025-11-09 18:47:51', 'https://lh3.googleusercontent.com/a/ACg8ocK80j4Lwk9wZ86m4Hknrvaaj2p3aqtMfKp6Vk7keCwzRGfFzuk=s96-c', '56052a9e5fbb442bd896cb9fa11c4d382d2d0c1a61303a7e2fedb5ce1bd37451', '2025-11-14 18:46:00', 1),
(10, 'admin1', 'admin1@gmail.com', '$2y$10$6XJGZShwnnXsRszphmLiOuw80S7bdKXB0jEDstIxWuLzSgcRVcS.y', 'admin', '2025-11-09 22:36:36', NULL, NULL, NULL, NULL, NULL, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `uniq_google_id` (`google_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
