1. Create database: login_methods
2. Import database.sql in phpMyAdmin
3. Update /core/db.php with your MySQL username/password/port

core/db.php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "login_methods";
$port = 3307; // change to their XAMPP port (usually 3306)

