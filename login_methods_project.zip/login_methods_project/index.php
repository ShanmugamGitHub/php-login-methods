<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Methods Project</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f7f8fa;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin: 0;
      padding-top: 40px;
    }

    h1 {
      color: #333;
      margin-bottom: 40px;
      text-align: center;
    }

    .method-card {
      background: white;
      padding: 30px 50px;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
      text-align: center;
      margin: 1rem;
      width: 350px;
    }

    .method-card h2 {
      margin-bottom: 20px;
      color: #444;
    }

    .btn {
      display: inline-block;
      margin: 10px;
      padding: 12px 25px;
      font-size: 16px;
      font-weight: bold;
      color: #fff;
      background: #007bff;
      border: none;
      border-radius: 8px;
      text-decoration: none;
      transition: background 0.3s ease;
    }

    .btn:hover {
      background: #0056b3;
    }

    footer {
      margin-top: 40px;
      font-size: 13px;
      color: #777;
      text-align: center;
    }
  </style>
</head>
<body>

  <h1>🔐 Login Methods Learning Project</h1>

  <!-- Method 1 -->
  <div class="method-card">
    <h2>Method 1: Form-Based Login</h2>
    <a href="methods/method1_form_login/login.php" class="btn">Login</a>
    <a href="methods/method1_form_login/register.php" class="btn">Register</a>
  </div>

  <!-- Method 2 -->
  <div class="method-card">
    <h2>Method 2: Token-Based Login (JWT)</h2>
    <a href="methods/method2_token_based/login.php" class="btn">Go to Login</a>
  </div>

  <!-- Method 3 -->
  <div class="method-card">
    <h2>Method 3: OAuth 2.0 Login (Google)</h2>
    <p>Sign in using your Google account securely.</p>
    <a href="methods/method3_oauth/login.php" class="btn">Login with Google</a>
  </div>

  <!-- Method 4 -->
  <div class="method-card">
    <h2>Method 4: Passwordless Login</h2>
    <p>Login using a one-time magic link sent to your email.</p>
    <a href="methods/method4_passwordless/request_link.php" class="btn">Send Magic Link</a>
  </div>

  <footer>
    Login Methods Learning Project — Shammu
  </footer>

</body>
</html>
