<?php
require_once "../../core/db.php"; // DB connection
require_once "../../core/session.php"; // for consistent session handling

// Composer autoload (PHPMailer)
require_once __DIR__ . '/../../phpmailer/src/PHPMailer.php';
require_once __DIR__ . '/../../phpmailer/src/SMTP.php';
require_once __DIR__ . '/../../phpmailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


$message = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);

    if ($email === "") {
        $message = "⚠️ Please enter your email address.";
    } else {
        // Step 1: Check if user exists
        $stmt = $conn->prepare("SELECT * FROM users WHERE email=? LIMIT 1");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($user = $result->fetch_assoc()) {

            // Step 2: Generate secure random token
            $token  = bin2hex(random_bytes(32)); // 64-char hex
            $expiry = date("Y-m-d H:i:s", time() + 1800); // 30 minutes from now

            // Step 3: Save token + expiry
            $update = $conn->prepare("UPDATE users SET magic_token=?, magic_expiry=?, magic_used=0 WHERE id=?");
            $update->bind_param("ssi", $token, $expiry, $user['id']);
            $update->execute();

            // Step 4: Create the magic link
            $loginLink = "http://localhost/login_methods_project/methods/method4_passwordless/verify_link.php?token=" . urlencode($token);

            // Step 5: Send email via PHPMailer
            $smtpHost = 'smtp.gmail.com';
            $smtpPort = 587;
            $smtpUser = 'shammu.web@gmail.com'; // 🔹 Your Gmail
            $smtpPass = 'tsxdhzpzakefbsfw';     // 🔹 Your App Password (not Gmail password!)

            $mailBody = "
                <p>Hello " . htmlspecialchars($user['name']) . ",</p>
                <p>Click below to log in. This link expires in <strong>30 minutes</strong> and can be used once.</p>
                <p><a href='" . htmlspecialchars($loginLink) . "' style='background:#007bff;color:white;padding:10px 20px;border-radius:6px;text-decoration:none;'>Login to Your Account</a></p>
                <p>If the button doesn’t work, copy & paste this link into your browser:</p>
                <p><small>" . htmlspecialchars($loginLink) . "</small></p>
                <p>Best regards,<br>Your App</p>
            ";

            $mail = new PHPMailer(true);
            try {
                // Server settings
                $mail->isSMTP();
                $mail->Host       = $smtpHost;
                $mail->SMTPAuth   = true;
                $mail->Username   = $smtpUser;
                $mail->Password   = $smtpPass;
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = $smtpPort;

                // Recipients
                $mail->setFrom($smtpUser, 'Your App');
                $mail->addAddress($user['email'], $user['name']);

                // Content
                $mail->isHTML(true);
                $mail->Subject = 'Your Magic Login Link';
                $mail->Body    = $mailBody;
                $mail->AltBody = "Open this link to login: $loginLink";

                $mail->send();
                $message = "✅ Magic login link emailed to <strong>" . htmlspecialchars($user['email']) . "</strong>. Please check your inbox (and spam).";
            } catch (Exception $e) {
                error_log("Mailer Error: " . $mail->ErrorInfo);
                $message = "⚠️ Could not send email. Here’s your link for testing:<br>
                            <a href='$loginLink'>$loginLink</a><br>
                            <small>Mailer error: " . htmlspecialchars($mail->ErrorInfo) . "</small>";
            }
        } else {
            $message = "❌ Email not found in our system.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Passwordless Login - Request Magic Link</title>
<style>
  body {
    font-family: Arial;
    background: #f4f6fa;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
  }
  .card {
    background: #fff;
    padding: 30px 40px;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    text-align: center;
    width: 420px;
  }
  h2 { margin-top: 0; color: #333; }
  input {
    margin: 10px 0;
    padding: 10px;
    width: 80%;
    border: 1px solid #ccc;
    border-radius: 5px;
  }
  button {
    margin-top: 10px;
    padding: 10px 25px;
    background: #007bff;
    border: none;
    color: white;
    border-radius: 5px;
    cursor: pointer;
  }
  button:hover { background: #0056b3; }
  .msg {
    margin-top: 20px;
    font-size: 14px;
    color: #333;
    word-wrap: break-word;
  }
  a { color: #007bff; text-decoration: none; }
  a:hover { text-decoration: underline; }
</style>
</head>
<body>
  <div class="card">
    <h2>🔐 Passwordless Login</h2>
    <p>Enter your email to receive a one-time login link.</p>
    <form method="POST">
      <input type="email" name="email" placeholder="Enter your email" required><br>
      <button type="submit">Send Magic Link</button>
    </form>
    <div class="msg"><?= $message ?></div>
  </div>
</body>
</html>
