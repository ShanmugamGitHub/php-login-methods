<?php
require_once "../../core/db.php";
require_once "../../core/session.php"; 

$message = "";

// Step 1: Read the token from the URL
$token = isset($_GET['token']) ? trim($_GET['token']) : '';

if ($token === '') {
    $message = "❌ Invalid or missing token.";
} else {
    // Step 2: Check if token exists and is valid
    $stmt = $conn->prepare("SELECT * FROM users WHERE magic_token=? AND magic_used=0 LIMIT 1");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($user = $result->fetch_assoc()) {
        $expiry = strtotime($user['magic_expiry']);
        $now = time();

        if ($now > $expiry) {
            $message = "⚠️ This magic link has expired. Please request a new one.";
        } else {
            // Step 3: Valid token → mark as used
            $used = $conn->prepare("UPDATE users SET magic_used=1 WHERE id=?");
            $used->bind_param("i", $user['id']);
            $used->execute();

            // Step 4: Log the user in (30 min session)
            startUserSession($user, 'passwordless');

            // Step 5: Redirect to correct dashboard
            if ($user['role'] === 'admin') {
                header("Location: ../../modules/admin/dashboard.php");
            } else {
                header("Location: ../../modules/user/dashboard.php");
            }
            exit;
        }
    } else {
        $message = "❌ Invalid or already used magic link.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Verify Magic Link</title>
<style>
  body {
    font-family: Arial;
    background: #f7f7f9;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
  }
  .card {
    background: #fff;
    padding: 30px 40px;
    border-radius: 10px;
    box-shadow: 0 3px 10px rgba(0,0,0,0.1);
    text-align: center;
    width: 420px;
  }
  .success { color: green; font-weight: bold; }
  .error { color: red; font-weight: bold; }
</style>
</head>
<body>
  <div class="card">
    <h2>Passwordless Login</h2>
    <p><?= $message ?></p>
    <p><a href="request_link.php">Back to Login Page</a></p>
  </div>
</body>
</html>
