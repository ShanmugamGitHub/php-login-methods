<?php
require_once "../../core/auth.php";

$error = ""; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

   
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';


    if ($email === '' || $password === '') {
        $error = "Please enter both email and password.";
    } else {
   
        $isLoggedIn = loginUser($email, $password);

        if (!$isLoggedIn) {
            $error = "Invalid email or password!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login - Method 1</title>
  <style>
    body {
      font-family: Arial;
      background: #f4f4f9;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }
    .card {
      background: #fff;
      padding: 30px 40px;
      border-radius: 10px;
      box-shadow: 0 3px 10px rgba(0,0,0,0.1);
      text-align: center;
    
    }
    input {
      margin: 8px 0;
      padding: 10px;
      width: 250px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }
    button {
      margin-top: 10px;
      padding: 10px 25px;
      background: #007bff;
      border: none;
      color: white;
      border-radius: 5px;
      cursor: pointer;
    }
    button:hover { background: #0056b3; }
    .error {
      color: red;
      margin-top: 10px;
      font-weight: bold;
    }
  </style>
</head>
<body>
  
  <div class="card">
    <h2>Login (Form-based Authentication)</h2>

    <form method="POST" autocomplete="off">
      <input type="email" name="email" placeholder="Email" required autocomplete="new-email"><br>
      <input type="password" name="password" placeholder="Password" required autocomplete="new-password"><br>
      <button type="submit">Login</button>
    </form>

  
    <?php if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($error)) : ?>
      <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <p>Don’t have an account? <a href="register.php">Register</a></p>

    <div style="margin-top:20px; background:#e9f5ff; padding:15px; border-radius:8px; font-size:14px; text-align:left;">
  <strong>Sample Credentials:</strong><br><br>
  <strong>Admin</strong><br>
  Username: <code>admin@gmail.com</code><br>
  Password: <code>admin@123</code><br><br>
  <strong>User</strong><br>
  Username: <code>user@gmail.com</code><br>
  Password: <code>user@123</code>
</div>
  </div>

  
</body>
</html>
