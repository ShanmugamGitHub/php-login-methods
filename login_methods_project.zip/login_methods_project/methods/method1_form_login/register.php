<?php
require_once "../../core/auth.php";

$message = "";
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $role     = $_POST['role'] ?? 'user';
if (!$name || !$email || !$password) {
        $message = "Please fill out all fields.";
    } else {
        global $conn;
        $stmt = $conn->prepare("SELECT id FROM users WHERE email=? LIMIT 1");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $message = "Email already registered. Please <a href='login.php'>login here</a>.";
        } elseif (registerUser($name, $email, $password, $role)) {
            $success = true;
            $message = "✅ Registration successful! <a href='login.php'>Login here</a>";
        } else {
            $message = "❌ Registration failed. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Register - Method 1</title>
  <style>
    body { font-family: Arial; background: #f4f4f9; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
    .card { background: #fff; padding: 30px 40px; border-radius: 10px; box-shadow: 0 3px 10px rgba(0,0,0,0.1); text-align: center; }
    input, select { margin: 8px 0; padding: 10px; width: 250px; border: 1px solid #ccc; border-radius: 5px; }
    button { margin-top: 10px; padding: 10px 25px; background: #28a745; border: none; color: white; border-radius: 5px; cursor: pointer; }
    button:hover { background: #218838; }
    .message { margin-top: 10px; color: <?= $success ? 'green' : 'red' ?>; font-weight: bold; }
  </style>
</head>
<body>
  <div class="card">
    <h2>Register (Form-based Login)</h2>
    <form method="POST" autocomplete="off">
      <input type="text" name="name" placeholder="Full Name" required><br>
      <input type="email" name="email" placeholder="Email" required autocomplete="new-email"><br>
      <input type="password" name="password" placeholder="Password" required autocomplete="new-password"><br>
      <select name="role">
        <option value="user">User</option>
        <option value="admin">Admin</option>
      </select><br>
      <button type="submit">Register</button>
    </form>
    <?php if (!empty($message)): ?>
      <div class="message"><?= $message ?></div>
    <?php endif; ?>
  </div>
</body>
</html>
