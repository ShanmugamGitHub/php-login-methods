<?php
function generate_jwt($payload, $secret = 'my_secret_key') {
    $header = base64_encode(json_encode(['typ'=>'JWT','alg'=>'HS256']));
    $payload = base64_encode(json_encode($payload));
    $signature = base64_encode(hash_hmac('sha256', "$header.$payload", $secret, true));
    return "$header.$payload.$signature";
}

function verify_jwt($token, $secret = 'my_secret_key') {
    $parts = explode('.', $token);
    if(count($parts) !== 3) return false;

    list($header, $payload, $signature) = $parts;
    $check = base64_encode(hash_hmac('sha256', "$header.$payload", $secret, true));
    if (!hash_equals($check, $signature)) return false;

    return json_decode(base64_decode($payload), true);
}
?>
