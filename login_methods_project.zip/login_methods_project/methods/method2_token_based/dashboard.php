<?php
require_once "jwt_helper.php";

$token = $_POST['token'] ?? '';

if (!$token) {
    echo "<h2 style='color:red;'>❌ No token provided.</h2>";
    echo "<p>Please login again to get a token.</p>";
    exit;
}

$data = verify_jwt($token);

if (!$data) {
    echo "<h2 style='color:red;'>❌ Invalid or tampered token.</h2>";
    exit;
}

if ($data['exp'] < time()) {
    echo "<h2 style='color:red;'>⚠️ Token expired. Please login again.</h2>";
    exit;
}

$email = htmlspecialchars($data['email']);
$role = htmlspecialchars($data['role']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Role-Based Dashboard</title>
<style>
  body {
    font-family: Arial, sans-serif;
    background: #f4f4f9;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
  }
  .card {
    background: #fff;
    padding: 30px 40px;
    border-radius: 10px;
    box-shadow: 0 3px 10px rgba(0,0,0,0.1);
    text-align: center;
    width: 450px;
  }
  h1 { color: #007bff; }
  h2 { color: #333; }
  ul { text-align: left; margin-top: 15px; }
  li { margin-bottom: 6px; }
  .role-badge {
    display: inline-block;
    background: <?= $role === 'admin' ? '#dc3545' : '#28a745' ?>;
    color: white;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 14px;
    margin-top: 10px;
  }
  .logout {
    display: inline-block;
    margin-top: 25px;
    text-decoration: none;
    color: white;
    background: #6c757d;
    padding: 10px 20px;
    border-radius: 6px;
  }
  .logout:hover { background: #5a6268; }
</style>
</head>
<body>
  <div class="card">
    <h1>Welcome <?= ucfirst($role) ?> 🎉</h1>
    <p><strong>Email:</strong> <?= $email ?></p>
    <div class="role-badge"><?= ucfirst($role) ?></div>

    <hr style="margin:20px 0;">

    <?php if ($role === 'admin'): ?>
      <h2>📋 Admin Dashboard</h2>
      <ul>
        <li>✅ Manage Users</li>
        <li>✅ View System Analytics</li>
        <li>✅ Edit / Delete Content</li>
        <li>✅ Access All Reports</li>
      </ul>
    <?php else: ?>
      <h2>👤 User Dashboard</h2>
      <ul>
        <li>✅ View Your Profile</li>
        <li>✅ Browse Available Courses</li>
        <li>✅ View Your Progress</li>
        <li>✅ Submit Feedback</li>
      </ul>
    <?php endif; ?>

    <a href="login.php" class="logout">Logout / Back to Login</a>
  </div>
</body>
</html>
