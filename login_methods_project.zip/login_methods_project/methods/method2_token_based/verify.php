<?php
require_once "jwt_helper.php";

header("Content-Type: application/json");


$token = $_GET['token'] ?? '';

if (!$token && isset($_SERVER['HTTP_AUTHORIZATION'])) {
    if (preg_match('/Bearer\s(\S+)/', $_SERVER['HTTP_AUTHORIZATION'], $matches)) {
        $token = $matches[1];
    }
}

if (!$token) {
    echo json_encode(["valid"=>false, "message"=>"No token provided"]);
    exit;
}

$data = verify_jwt($token);
if (!$data) {
    echo json_encode(["valid"=>false, "message"=>"Invalid or expired token"]);
    exit;
}

if ($data['exp'] < time()) {
    echo json_encode(["valid"=>false, "message"=>"Token expired"]);
    exit;
}

echo json_encode(["valid"=>true, "user"=>$data]);
?>
