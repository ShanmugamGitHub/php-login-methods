<?php
require_once "../../core/db.php";
require_once "jwt_helper.php";

$message = "";
$token = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($email === '' || $password === '') {
        $message = "Please enter both email and password.";
    } else {
        // 1) Find the user by email
        $stmt = $conn->prepare("SELECT * FROM users WHERE email=? LIMIT 1");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        // 2) If found, verify password
        if ($user = $result->fetch_assoc()) {
            if (password_verify($password, $user['password'])) {
                // 3) Build JWT payload with role + expiry
                $payload = [
                    "user_id" => $user['id'],
                    "email"   => $user['email'],
                    "role"    => $user['role'],
                    "iat"     => time(),              // issued at
                    "exp"     => time() + 60*60       // expires in 1 hour
                ];

                // 4) Generate token
                $token = generate_jwt($payload);

                // 5) Show success message + token
                $message = "Login successful!";
            } else {
                $message = "Invalid password.";
            }
        } else {
            $message = " No user found with this email.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Token-Based Login (Method 2)</title>
<style>
  body { font-family: Arial, sans-serif; background:#f4f4f9; display:flex; justify-content:center; align-items:center; height:100vh; margin:0; }
  .card { background:#fff; padding:30px 40px; border-radius:10px; box-shadow:0 3px 10px rgba(0,0,0,0.1); width:400px; text-align:center; }
  input { width:90%; padding:10px; margin:8px 0; border:1px solid #ccc; border-radius:5px; }
  button { background:#007bff; color:#fff; border:none; padding:10px 25px; margin-top:10px; border-radius:5px; cursor:pointer; }
  button:hover { background:#0056b3; }
  pre { background:#f1f1f1; text-align:left; padding:10px; border-radius:5px; overflow-x:auto; }
  .msg { margin-top:15px; font-weight:bold; color:#333; }
</style>
</head>
<body>
  <div class="card">
    <h2>Method 2: Token-Based Login</h2>

    <!-- Simple login form -->
    <form method="POST" autocomplete="off">
      <input type="email" name="email" placeholder="Email" required><br>
      <input type="password" name="password" placeholder="Password" required><br>
      <button type="submit">Login</button>
    </form>

    <!-- Result messages -->
    <?php if(!empty($message)): ?>
      <div class="msg"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <!-- Show token and actions -->
    <?php if(!empty($token)): ?>
      <h4>Your Token:</h4>
      <pre><?= htmlspecialchars($token) ?></pre>
<!-- 
      <div style="margin-top:15px;">
        <a href="verify.php?token=<?= urlencode($token) ?>" target="_blank">🔍 Verify Token</a>
      </div> -->

      <!-- Button to go to protected dashboard with token -->
      <form action="dashboard.php" method="POST" style="margin-top:15px;">
        <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
        <button type="submit" style="background:#28a745;"> Go to Token-Protected Dashboard</button>
      </form>
    <?php endif; ?>
    
<!-- Sample credentials box -->
<div style="margin-top:20px; background:#e9f5ff; padding:15px; border-radius:8px; font-size:14px; text-align:left;">
  <strong>Sample Credentials:</strong><br><br>
  <strong>Admin</strong><br>
  Username: <code>admin@gmail.com</code><br>
  Password: <code>admin@123</code><br><br>
  <strong>User</strong><br>
  Username: <code>user@gmail.com</code><br>
  Password: <code>user@123</code>
</div>

  </div>
</body>
</html>
