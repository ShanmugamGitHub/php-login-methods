<?php
require_once "config.php";

$params = [
  'client_id'     => GOOGLE_CLIENT_ID,
  'redirect_uri'  => GOOGLE_REDIRECT_URI,
  'response_type' => 'code',
  'scope'         => 'openid email profile',
  'access_type'   => 'online',          // 'offline' if you need refresh tokens
  'prompt'        => 'select_account'   // do NOT force 'consent' every time
];

$google_login_url = GOOGLE_AUTH_URL . '?' . http_build_query($params);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login with Google - Method 3</title>
  <style>
    body { font-family: Arial; background:#f7f7f7; text-align:center; padding-top:100px; }
    .card { display:inline-block; background:#fff; padding:40px 60px; border-radius:10px; box-shadow:0 3px 10px rgba(0,0,0,.1); }
    a.btn { display:inline-block; background:#db4437; color:#fff; padding:12px 22px; border-radius:6px; text-decoration:none; font-weight:700; }
    a.btn:hover { background:#c23321; }
  </style>
</head>
<body>
  <div class="card">
    <h2>Method 3: OAuth 2.0 (Google)</h2>
    <p>Authenticate securely using your Google account.</p>
    <a class="btn" href="<?= htmlspecialchars($google_login_url) ?>">🔐 Login with Google</a>
  </div>
</body>
</html>
