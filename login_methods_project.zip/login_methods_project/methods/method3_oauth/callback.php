<?php
require_once "config.php";
require_once "../../core/db.php";
require_once "../../core/session.php"; // ✅ This loads startUserSession()


if (!isset($_GET['code'])) {
    echo "<h3>❌ No authorization code.</h3>";
    exit;
}

/** Step 1: exchange code for token */
$tokenRequest = curl_init(GOOGLE_TOKEN_URL);
curl_setopt_array($tokenRequest, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => http_build_query([
        'code' => $_GET['code'],
        'client_id' => GOOGLE_CLIENT_ID,
        'client_secret' => GOOGLE_CLIENT_SECRET,
        'redirect_uri' => GOOGLE_REDIRECT_URI,
        'grant_type' => 'authorization_code'
    ])
]);
$response = curl_exec($tokenRequest);
curl_close($tokenRequest);
$tokenData = json_decode($response, true);

if (empty($tokenData['access_token'])) {
    echo "<h3>❌ Failed to get access token.</h3><pre>".htmlspecialchars($response)."</pre>";
    exit;
}

/** Step 2: get Google profile */
$userRequest = curl_init(GOOGLE_USERINFO_URL);
curl_setopt_array($userRequest, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => ['Authorization: Bearer '.$tokenData['access_token']]
]);
$userResponse = curl_exec($userRequest);
curl_close($userRequest);
$g = json_decode($userResponse, true);

$googleId = $g['id'] ?? ($g['sub'] ?? null); // sometimes 'sub' is used
$email    = $g['email'] ?? null;
$name     = $g['name'] ?? 'Google User';
$picture  = $g['picture'] ?? '';


if (!$googleId || !$email) {
    echo "<h3>❌ Missing google id or email.</h3>";
    exit;
}

/** Step 3: upsert user (no duplicate saves on second login) */
$now = date('Y-m-d H:i:s');

// 3a) try to find by google_id first
$find = $conn->prepare("SELECT * FROM users WHERE google_id=? LIMIT 1");
$find->bind_param("s", $googleId);
$find->execute();
$res = $find->get_result();
$user = $res->fetch_assoc();

if (!$user) {
    // 3b) if no google_id match, see if email exists (user might have registered by email first)
    $findByEmail = $conn->prepare("SELECT * FROM users WHERE email=? LIMIT 1");
    $findByEmail->bind_param("s", $email);
    $findByEmail->execute();
    $res2 = $findByEmail->get_result();
    $user = $res2->fetch_assoc();

    if ($user) {
        // upgrade existing account: attach google_id
        $upd = $conn->prepare("UPDATE users SET google_id=?, last_login=? WHERE id=?");
        $upd->bind_param("ssi", $googleId, $now, $user['id']);
        $upd->execute();
    } else {
        // first-time Google login → insert new user (default role=user)
        $role = 'user';
        // dummy password just to satisfy NOT NULL (never used for Google sign-in)
        $dummyHash = password_hash(bin2hex(random_bytes(8)), PASSWORD_DEFAULT);
       $ins = $conn->prepare("INSERT INTO users (name, email, password, role, google_id, last_login, picture) VALUES (?, ?, ?, ?, ?, ?, ?)");
        if (!$ins) {
            die("SQL error: " . $conn->error);
        }
        $ins->bind_param("sssssss", $name, $email, $dummyHash, $role, $googleId, $now, $picture);
        $ins->execute();

        // fetch the created user row back
        $newId = $ins->insert_id;
        $get = $conn->prepare("SELECT * FROM users WHERE id=? LIMIT 1");
        $get->bind_param("i", $newId);
        $get->execute();
        $user = $get->get_result()->fetch_assoc();
    }
} else {

$upd = $conn->prepare("UPDATE users SET last_login=?, picture=? WHERE id=?");
$upd->bind_param("ssi", $now, $picture, $user['id']);
$upd->execute();


}

/** Step 4: start a 1-hour session and redirect by role */
$user['picture'] = $picture;
startUserSession($user, 'google');

if (($user['role'] ?? 'user') === 'admin') {
    header("Location: ../../modules/admin/dashboard.php");
} else {
    header("Location: ../../modules/user/dashboard.php");
}
exit;
