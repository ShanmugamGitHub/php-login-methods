    <?php
// OAuth 2.0 Client Credentials
define('GOOGLE_CLIENT_ID', '940302061473-ee613shopbv8thqvnflrju37l14cnhu8.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');
define('GOOGLE_REDIRECT_URI', 'http://localhost/login_methods_project/methods/method3_oauth/callback.php');

// Google OAuth endpoints
define('GOOGLE_AUTH_URL', 'https://accounts.google.com/o/oauth2/v2/auth');
define('GOOGLE_TOKEN_URL', 'https://oauth2.googleapis.com/token');
define('GOOGLE_USERINFO_URL', 'https://www.googleapis.com/oauth2/v2/userinfo');
?>
