<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}


function startUserSession(array $user, string $method = 'form') {
    session_regenerate_id(true);

    $duration = ($method === 'passwordless') ? 1800 : 3600; // 30 min vs 1 hr

    $_SESSION['user_id']      = $user['id'];
    $_SESSION['email']        = $user['email'];
    $_SESSION['name']         = $user['name'] ?? '';
    $_SESSION['role']         = $user['role'];
    $_SESSION['login_at']     = time();
    $_SESSION['expires_at']   = time() + $duration;
    $_SESSION['login_method'] = $method;
    $_SESSION['picture'] = $user['picture'] ?? "https://png.pngtree.com/png-vector/20231019/ourmid/pngtree-user-profile-avatar-png-image_10211467.png" . urlencode($user['name']);

}


function requireAuth(?string $role = null) {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    if (empty($_SESSION['user_id'])) {
        // No session
        logoutToLogin();
    }

    if (!empty($_SESSION['expires_at']) && time() > $_SESSION['expires_at']) {
        // Expired
        logoutToLogin();
    }

    if ($role && ($_SESSION['role'] ?? '') !== $role) {
        // Unauthorized role
        logoutToLogin();
    }
}



//  Logout for method1 and common use

function logout() {
    session_unset();
    session_destroy();
    header("Location: ../../methods/method1_form_login/login.php");
    exit;
}


//   Logout to home menu
 
function logoutToLogin() {
    session_unset();
    session_destroy();
    header("Location: ../../index.php");
    exit;
}


