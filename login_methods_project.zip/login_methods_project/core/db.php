<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "login_methods";

$conn = new mysqli($host, $user, $pass, $dbname, 3307);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
?>
