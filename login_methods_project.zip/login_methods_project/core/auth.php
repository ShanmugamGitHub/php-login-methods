<?php
require_once "db.php";
require_once "session.php";

function registerUser($name, $email, $password, $role = 'user') {
    global $conn;
    $hashed = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $hashed, $role);
    return $stmt->execute();
}

function loginUser($email, $password) {
    global $conn;
    require_once __DIR__ . "/session.php"; // ensure session is loaded

    $stmt = $conn->prepare("SELECT * FROM users WHERE email=? LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($user = $result->fetch_assoc()) {
        if (password_verify($password, $user['password'])) {
            //  Start a session correctly
            startUserSession($user, 'form');

            //  Redirect based on role
            if ($user['role'] === 'admin') {
                header("Location: ../../modules/admin/dashboard.php");
            } else {
                header("Location: ../../modules/user/dashboard.php");
            }
            exit;
        }
    }

    return false; 
}

?>
