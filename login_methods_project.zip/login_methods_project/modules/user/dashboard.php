<?php
require_once "../../core/session.php";
requireAuth('user');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>User Dashboard</title>
<style>
  body {
    font-family: Arial;
    padding: 40px;
    background: #f7f7fa;
  }
  .profile {
    display: flex;
    align-items: center;
    gap: 15px;
  }
  .profile img {
    width: 64px;
    height: 64px;
    border-radius: 50%;
    object-fit: cover;
    border: 2px solid #ccc;
  }
</style>
</head>
<body>
  <div class="profile">


    <?php if (!empty($_SESSION['picture'])): ?>
    <img src="<?= $_SESSION['picture'] ?>" width="90" height="90" style="border-radius:50%">
<?php endif; ?>

    <div>
      <h1>Welcome <?= htmlspecialchars($_SESSION['name']) ?>!</h1>
      <p><?= htmlspecialchars($_SESSION['email']) ?></p>
      <p>Login method: <?= htmlspecialchars($_SESSION['login_method']) ?></p>
    </div>
  </div>
  <p><a href="logout.php">Logout</a></p>
</body>
</html>
