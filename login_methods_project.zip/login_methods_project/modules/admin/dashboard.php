<?php
require_once "../../core/session.php";
requireAuth('admin');
?>
<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"><title>Admin Dashboard</title></head>
<body style="font-family:Arial;padding:40px">
  <h1>Welcome <?= htmlspecialchars($_SESSION['name']) ?>!</h1>
  <p>Email: <?= htmlspecialchars($_SESSION['email']) ?></p>
  <p>Role: <?= htmlspecialchars($_SESSION['role']) ?></p>
  <p>Login method: <?= htmlspecialchars($_SESSION['login_method']) ?></p>
  <a href="logout.php">Logout</a>
</body>
</html>
