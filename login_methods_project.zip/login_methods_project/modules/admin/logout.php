<?php
require_once "../../core/session.php";
logoutToLogin();
?>
